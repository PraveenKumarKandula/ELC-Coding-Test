import React from 'react';
import ReactDOM from 'react-dom';

import Menu from './components/menu';
import Home from './components/home';
import {Footer} from './components/footer';

class App extends React.Component {
    render() {
        return (
            <div className="App">
                <Menu />
                <Home />
                <Footer />
            </div>
        );
    }
}
ReactDOM.render(<App />, document.getElementById('root'));
