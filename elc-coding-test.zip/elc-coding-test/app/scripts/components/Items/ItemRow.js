import React from 'react'
const productAbout ={
    textAlign: "justify",
    paddingRight: "60px"
}
const productRow = {
    flex: "1 0 21%",
    paddingBottom: "50px"
}
const ItemRow = ({item, index}) => {
    return (
        <div className="item-row" style={productRow}>
            <img className="item-picture" src={item.picture} />
            <p className="item-name"><b>{item.name}</b></p>
            <p className="item-about" style={productAbout}>{item.about}</p>
            <p className="item-price" style={{paddingTop:"10px"}}>Price: $ <b>{item.price}</b></p>
        </div>
    )
}
export default ItemRow