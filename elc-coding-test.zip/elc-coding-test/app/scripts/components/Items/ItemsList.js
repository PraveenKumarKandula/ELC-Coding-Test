import React from 'react'
import ItemRow from './ItemRow'
const productAlignment = {
    width: "100%",
    display: "flex",
    paddingTop: "30px",
    paddingLeft: "20px",
    flexWrap: "wrap"
}
const mapItems = (item, index) => {   
    return(
        <ItemRow item={item} key={index}/>
        )
}

const ItemsList = ({items}) =>{
    return(
    <div id="itemsList" style={productAlignment}>
        {items.map(mapItems)}
    </div>)
}

export default ItemsList