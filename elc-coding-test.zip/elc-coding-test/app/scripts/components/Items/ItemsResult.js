import React from 'react'
import ItemsList from './ItemsList'

const ItemsResult = ({items}) => {
    return (
        <div>
            <ItemsList items={items}/>
        </div>
    )
}

export default ItemsResult;