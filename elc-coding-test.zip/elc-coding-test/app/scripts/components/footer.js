import React from 'react';
const navitem = {
    fontFamily: "Helvetica, Arial, Sans-Serif",
    fontSize: "17px",
    color: "#FFF",
    paddingTop: "15px",
    textAlign: "center",
    lineHeight: "$lineHeightForNav",
    textTransform: "uppercase",
    textDecoration: "none",
    whiteSpace: "nowrap",
    borderBottom: "1px solid transparent",
    marginRight: "20px",
}
const footerAlign={
    paddingRight: "20px",
    float: "left"
}
const offerAlign={
    float: "right"
}
export class Footer extends React.Component {
    constructor() {
        super();
    }

    render() {
        return (
            <footer className="container" style={{position:"absolute",bottom:"0",width:"100%",height:"60px"}}>
                    <div className="footer-container" style={{width: "100%", height: "60px", backgroundColor: "black",padding: "0 20px",textAlign: "left"}}>
                        <nav style={navitem}>
                            <a style={footerAlign}>CHAT LIVE</a>
                            <a style={footerAlign}>|</a>
                            <a style={footerAlign}>TRY IT ON</a>
                            <a style={footerAlign}>|</a>
                            <a style={footerAlign}>JOIN OUR LOYALTY PROGRAM</a>
                            <a style={offerAlign}>OFFERS</a>
                        </nav>
                    </div>
            </footer>
        );
    }
}

export default Footer;