import React from 'react';
import ItemsResult from './Items/ItemsResult';
import axios from 'axios';
import data from './data/data'

export class Menu extends React.Component {
    constructor() {
        super();
        this.state = {
            showingSearch: false,
            searchValue:''
        };
    }

    onSearch(e) {
        this.setState({searchValue: e.target.value});
        this.setState({ result: []});
        if(this.state.searchValue.length>1) {
            this.getResult(this.state.searchValue)
        }
    }

    showSearchContainer(e) {
        e.preventDefault();
        this.setState({
            showingSearch: !this.state.showingSearch,
            searchValue:'',
            result:[]
        });
    }

    getResult(searchValue) {
        this.setState({loading: true});
        /**axios.get(`https://localhost:3035?filter=${searchValue}`)
            .then(res => {
            this.setState({result:res, loading: false});
        })
        .catch(err=>{
            this.setState({loading: false});
            console.log(err);
        })**/
        this.setState({result: data, loading: false});
    }

    render() {
        const { showingSearch, result, loading } = this.state;
        console.log("data",result);
        return (
            <header className="menu">
                <div className="menu-container">
                    <div className="nav-item" tabindex="0">
                            <p style={{display:"inline"}}>WE'RE OPENING AGAIN SOON! <a href="/store-opening" className="learn-link" role="link" aria-label="Learn More">LEARN MORE</a></p>
                            <a style={{float:"right", color: "#FFF"}} href="/login" role="link" title="Click to Signup M·A·C Cosmetics">email/sign-up</a>
                    </div>
                    <div className="menu-holder">
                        <h1>MAC</h1>
                        <nav>
                            <a href="#" className="nav-item">NEW</a>
                            <a href="#" className="nav-item">BEST SELLER</a>
                            <a href="#" className="nav-item">LIPS</a>
                            <a href="#" className="nav-item">FACE</a>
                            <a href="#" className="nav-item">EYES</a>
                            <a href="#" className="nav-item">BRUSHES</a>
                            <a href="#" className="nav-item">SKIN</a>
                            <a href="#" className="nav-item">INSPIRATION</a>
                            <a href="#" className="nav-item">VIRTUAL TRY-ON</a>
                            <a href="#" className="nav-item">STORES+SERVICES</a>

                            <a href="#" onClick={(e) => this.showSearchContainer(e)}>
                                <i className="material-icons search">search</i>
                            </a>
                        </nav>
                    </div>
                </div>
                <div className={(showingSearch ? "showing " : "") + "search-container"}>
                    <input type="text" value={ this.state.searchValue} onChange={(e) => this.onSearch(e)} />
                    <a href="#" onClick={(e) => this.showSearchContainer(e)}>
                        <i className="material-icons close">close</i>
                    </a>
                    {loading && "Loading..."}
                    {showingSearch && result 
                        && <ItemsResult items={result} searchValue={this.state.searchValue} />}
                </div>
            </header>
        );
    }
}

export default Menu;