import React from 'react';

export class Home extends React.Component {
    render() {
        return (
            <section id="home">
                <div className="content" style={{marginTop: "20px"}}>
                    <p>ELC Coding Test...</p>
                </div>
            </section>
        );
    }
}

export default Home;